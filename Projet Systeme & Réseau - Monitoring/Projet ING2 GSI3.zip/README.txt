Ce projet a été conçu pour une plateforme Linux, pour pouvoir compiler et exécuter le projet sous Windows il faut modifier le Makefile et ré-importer les packages réseau adaptés dans le code

Pour complier l'ensemble du programme il faut utiliser la commande :

make

puis pour executer , lancez :

./bin/executable

